function menu(x)
{
    x.classlist.toggle('change');
}